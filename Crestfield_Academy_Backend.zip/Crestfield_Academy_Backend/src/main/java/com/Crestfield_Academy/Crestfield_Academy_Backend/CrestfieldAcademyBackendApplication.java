package com.Crestfield_Academy.Crestfield_Academy_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrestfieldAcademyBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrestfieldAcademyBackendApplication.class, args);
	}

}
