package com.Crestfield_Academy.Crestfield_Academy_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrestfieldAcademyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
